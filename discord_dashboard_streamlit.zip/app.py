
import streamlit as st
import requests
from datetime import datetime

st.set_page_config(page_title="디스코드 관리 패널", page_icon="🛠️")

st.title("🛠️ 디스코드 관리 패널 (대시보드)")

st.sidebar.header("설정")
bot_token = st.sidebar.text_input("봇 토큰", type="password", help="읽기 전용 API로 일부 정보 조회 시 사용 (선택)")
guild_id = st.sidebar.text_input("서버(Guild) ID", help="서버 ID를 입력하세요")

st.sidebar.markdown("---")
st.sidebar.caption("⚠️ Streamlit 환경에서는 봇을 실행하지 않습니다. 이 패널은 정보 조회/시각화용입니다.")

def get_headers(token: str):
    return {"Authorization": f"Bot {token}"} if token else {}

def fetch_guild_info(token, gid):
    if not token or not gid:
        return None, "토큰/서버ID 필요"
    try:
        url = f"https://discord.com/api/v10/guilds/{gid}"
        r = requests.get(url, headers=get_headers(token))
        if r.status_code == 200:
            return r.json(), None
        return None, f"오류: {r.status_code} {r.text}"
    except Exception as e:
        return None, str(e)

def fetch_channels(token, gid):
    if not token or not gid:
        return None, "토큰/서버ID 필요"
    try:
        url = f"https://discord.com/api/v10/guilds/{gid}/channels"
        r = requests.get(url, headers=get_headers(token))
        if r.status_code == 200:
            return r.json(), None
        return None, f"오류: {r.status_code} {r.text}"
    except Exception as e:
        return None, str(e)

def fetch_members_preview():
    # Streamlit 환경에서는 Gateway 연결이 없으므로 멤버 전체 조회는 제한
    # 대신 안내 메시지
    return None, "멤버 전체 조회는 봇 Gateway 연결이 필요합니다 (서버 실행 환경에서 별도 구현)."

tab1, tab2, tab3 = st.tabs(["📊 서버 정보", "📁 채널 목록", "📜 로그(업로드)"])

with tab1:
    st.subheader("📊 서버 정보")
    if st.button("불러오기", key="guild_btn"):
        data, err = fetch_guild_info(bot_token, guild_id)
        if err:
            st.error(err)
        else:
            st.success("불러오기 성공")
            col1, col2 = st.columns(2)
            with col1:
                st.metric("서버 이름", data.get("name", "-"))
                st.metric("서버 ID", data.get("id", "-"))
            with col2:
                st.metric("Owner ID", data.get("owner_id", "-"))
                st.metric("Verification Level", data.get("verification_level", "-"))
            st.json(data)

with tab2:
    st.subheader("📁 채널 목록")
    if st.button("채널 불러오기", key="ch_btn"):
        data, err = fetch_channels(bot_token, guild_id)
        if err:
            st.error(err)
        else:
            st.success(f"{len(data)}개 채널")
            # 간단 테이블
            rows = []
            for ch in data:
                rows.append({
                    "name": ch.get("name"),
                    "id": ch.get("id"),
                    "type": ch.get("type"),
                    "position": ch.get("position"),
                })
            st.dataframe(rows, use_container_width=True)

with tab3:
    st.subheader("📜 로그 보기 (파일 업로드)")
    st.caption("봇 서버에서 생성한 logs.json 또는 .txt를 업로드해 확인하세요")
    file = st.file_uploader("로그 파일 업로드", type=["json", "txt"])
    if file:
        try:
            content = file.read().decode("utf-8", errors="ignore")
            lines = content.splitlines()
            st.success(f"총 {len(lines)} 줄")
            show_n = st.slider("표시 개수", 10, 500, 100)
            for line in lines[-show_n:][::-1]:
                st.code(line)
        except Exception as e:
            st.error(str(e))

st.markdown("---")
st.caption(f"마지막 새로고침: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
