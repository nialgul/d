
# 디스코드 관리 패널 (Streamlit)

## 기능
- 서버 정보 조회 (REST API)
- 채널 목록 조회
- 로그 파일 업로드 및 조회

## 실행
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 배포 (Streamlit Community Cloud)
- Repository 업로드
- Main file: `app.py`
- Secrets에 토큰 넣고 싶다면:
```toml
DISCORD_BOT_TOKEN = "여기에_토큰"
```

## 주의
- Streamlit에서는 봇 Gateway 연결이 없어 멤버 전체 조회/실시간 이벤트는 제한됩니다.
